from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

PRIMARY_MODES = ("SEQUENTIAL_A", "COUPLED_B", "HYBRID_C", "CALIBRATED_D", "CHANGEPOINT_E")
POSTHOC_MODES = ("CHANGEPOINT_HOLD_F",)
MODES = PRIMARY_MODES + POSTHOC_MODES


def canonical(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode()).hexdigest()


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


@dataclass
class ExecutionGuard:
    environment: str
    capability: str
    permit: str
    actuator_route: bool = True
    revoked: bool = False

    def check(self) -> tuple[bool, str]:
        if not self.actuator_route:
            return False, "ACTUATOR_ROUTE_ABSENT"
        if self.revoked:
            return False, "EXECUTION_PERMIT_REVOKED"
        if self.permit == "ABSENT":
            return False, "EXECUTION_PERMIT_ABSENT"
        if self.permit == "WRONG_ENVIRONMENT":
            return False, "ENVIRONMENT_SCOPE_MISMATCH"
        if self.permit == "WRONG_CAPABILITY":
            return False, "CAPABILITY_SCOPE_MISMATCH"
        if self.permit != "VALID":
            return False, "EXECUTION_PERMIT_INVALID"
        return True, "ALLOW"


class Simulator:
    def __init__(self, fixture: dict[str, Any], scenario: dict[str, Any], mode: str):
        if mode not in MODES:
            raise ValueError(mode)
        self.fixture = fixture
        self.s = scenario
        self.mode = mode
        self.policy = fixture["calibrationPolicy"]
        self.cp = fixture["changePointPolicy"]
        self.tick = 0
        self.world_target = int(scenario["startTarget"])
        self.plan = int(scenario["startTarget"])
        self.max_ticks = int(scenario.get("maxTicks", fixture["limits"]["maxLogicalTicks"]))
        self.commit_ticks = {int(x) for x in scenario.get("commitTicks", [])}
        self.events_by_tick: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for ev in scenario.get("events", []):
            self.events_by_tick[int(ev["at"])].append(dict(ev))
        self.guard = ExecutionGuard(
            fixture["environment"],
            fixture["capability"],
            scenario.get("permit", "VALID"),
            bool(scenario.get("actuatorRoute", True)),
        )
        self.ledger: list[dict[str, Any]] = []
        self.evidence: list[dict[str, Any]] = []
        self.epoch_start = 0
        self.source_reliability: dict[str, float] = defaultdict(lambda: 0.75)
        self.last_change_tick: int | None = None
        self.pending_change_tick: int | None = None
        self.world_changes: list[dict[str, Any]] = []
        self.last_change_candidate: int | None = None
        self.last_detected_cp_tick: int | None = None
        self.metrics = Counter({
            "false_positive_preemptions": 0,
            "false_negative_delay_ticks": 0,
            "bad_commits": 0,
            "held_commits": 0,
            "actions_executed": 0,
            "reasoning_events": 0,
            "coupled_activations": 0,
            "uncertainty_activations": 0,
            "deliberative_bursts": 0,
            "change_points_detected": 0,
            "spurious_change_points": 0,
            "stale_evidence_invalidated": 0,
            "source_reliability_updates": 0,
            "true_change_points_detected": 0,
            "missed_world_changes": 0,
            "change_point_detection_delay_ticks": 0,
        })
        self.observation_truth: list[dict[str, bool]] = []

    def emit(self, kind: str, **payload: Any) -> None:
        event = {"seq": len(self.ledger) + 1, "tick": self.tick, "kind": kind, "payload": payload}
        event["eventDigest"] = digest({k: event[k] for k in ("seq", "tick", "kind", "payload")})
        self.ledger.append(event)

    def _update_delay(self) -> None:
        if self.plan != self.world_target:
            self.metrics["false_negative_delay_ticks"] += 1

    def _observation(self, ev: dict[str, Any]) -> None:
        rec = {
            "tick": self.tick,
            "source": str(ev["source"]),
            "value": int(ev["value"]),
            "confidence": float(ev["confidence"]),
            "epoch": self.epoch_start,
        }
        self.evidence.append(rec)
        self.emit("OBSERVATION", **rec)
        truth_positive = rec["value"] == self.world_target and rec["value"] != self.plan
        decision_positive = False

        old_plan = self.plan
        if self.mode == "COUPLED_B":
            if rec["value"] != self.plan:
                self.metrics["coupled_activations"] += 1
                self._set_plan(rec["value"], "COUPLED_OBSERVATION")
        elif self.mode == "HYBRID_C":
            if rec["value"] != self.plan:
                if rec["confidence"] >= self.policy["hybridHardConfidence"]:
                    self.metrics["coupled_activations"] += 1
                    self._set_plan(rec["value"], "HYBRID_HARD_CONTRADICTION")
                else:
                    self.metrics["uncertainty_activations"] += 1
                    self.emit("UNCERTAINTY", candidate=rec["value"], confidence=rec["confidence"])
        elif self.mode == "CALIBRATED_D":
            self._calibrated_step(rec, change_point=False)
        elif self.mode in ("CHANGEPOINT_E", "CHANGEPOINT_HOLD_F"):
            self._reliability_update(rec)
            self._change_point_step(rec)
        decision_positive = self.plan != old_plan and self.plan == rec["value"]
        self.observation_truth.append({"truth": truth_positive, "decision": decision_positive})

    def _set_plan(self, value: int, reason: str) -> None:
        value = int(value)
        if value == self.plan:
            return
        old = self.plan
        self.plan = value
        self.metrics["reasoning_events"] += 1
        if value != self.world_target:
            self.metrics["false_positive_preemptions"] += 1
        self.emit("PLAN_PREEMPT", old=old, new=value, reason=reason, worldTargetAtDecision=self.world_target)

    def _recent_evidence(self, *, epoch_only: bool = False) -> list[dict[str, Any]]:
        cutoff = self.tick - int(self.policy["evidenceWindowTicks"]) + 1
        out = [x for x in self.evidence if x["tick"] >= cutoff]
        if epoch_only:
            out = [x for x in out if x["tick"] >= self.epoch_start]
        return out

    def _score_candidates(self, *, epoch_only: bool = False, reliability: bool = False) -> dict[int, dict[str, Any]]:
        recent = self._recent_evidence(epoch_only=epoch_only)
        grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for r in recent:
            grouped[int(r["value"])].append(r)
        scored: dict[int, dict[str, Any]] = {}
        decay_base = float(self.policy["confidenceDecayPerTick"])
        for value, rows in grouped.items():
            strongest: dict[str, float] = {}
            counts = Counter()
            raw_conf = []
            for r in rows:
                age = self.tick - r["tick"]
                weight = float(r["confidence"]) * (decay_base ** age)
                if reliability:
                    weight *= self.source_reliability[r["source"]]
                strongest[r["source"]] = max(strongest.get(r["source"], 0.0), weight)
                counts[r["source"]] += 1
                raw_conf.append(float(r["confidence"]))
            combined = 1.0
            for w in strongest.values():
                combined *= (1.0 - clamp(w, 0.0, 0.999))
            combined = 1.0 - combined
            persistence = max(counts.values()) if counts else 0
            bonus = min(
                max(0, persistence - 1) * float(self.policy["persistenceBonusPerRepeat"]),
                float(self.policy["maxPersistenceBonus"]),
            )
            scored[value] = {
                "score": clamp(combined + bonus, 0.0, 1.0),
                "sources": len(strongest),
                "persistence": persistence,
                "maxConfidence": max(raw_conf) if raw_conf else 0.0,
                "rows": rows,
            }
        return scored

    def _calibrated_step(self, rec: dict[str, Any], *, change_point: bool) -> None:
        if rec["value"] == self.plan:
            return
        scored = self._score_candidates(epoch_only=change_point, reliability=False)
        cand = scored.get(rec["value"], {"score": 0, "sources": 0, "persistence": 0, "maxConfidence": 0})
        cur = scored.get(self.plan, {"score": 0})
        margin = cand["score"] - cur["score"]
        hard = cand["maxConfidence"] >= self.policy["hardContradictionConfidence"]
        corroborated = cand["sources"] >= self.policy["corroborationSources"] and cand["score"] >= self.policy["corroborationScore"]
        persistent = cand["persistence"] >= self.policy["persistenceObservations"] and cand["score"] >= self.policy["persistenceScore"]
        enough_margin = margin >= self.policy["minimumMargin"]
        if hard or (corroborated and enough_margin) or (persistent and enough_margin):
            if not hard:
                self.metrics["deliberative_bursts"] += 1
                self.emit("DELIBERATIVE_BURST", candidate=rec["value"], score=round(cand["score"], 6), margin=round(margin, 6))
            self.metrics["coupled_activations"] += 1
            self._set_plan(rec["value"], "CHANGEPOINT_CALIBRATED" if change_point else "CALIBRATED_ESCALATION")
        else:
            self.metrics["uncertainty_activations"] += 1
            self.emit("UNCERTAINTY", candidate=rec["value"], score=round(cand["score"], 6), margin=round(margin, 6))

    def _reliability_update(self, rec: dict[str, Any]) -> None:
        # Reliability is local, bounded metadata. It is never authority and never ground truth.
        recent = [x for x in self.evidence if x is not rec and self.tick - x["tick"] <= self.cp["recentTicks"]]
        src = rec["source"]
        before = self.source_reliability[src]
        same = [x for x in recent if x["source"] != src and x["value"] == rec["value"]]
        conflict = [x for x in recent if x["source"] != src and x["value"] != rec["value"] and x["confidence"] >= 0.55]
        if same:
            after = before + self.cp["sourceAgreementGain"]
        elif conflict:
            # Penalize only mildly; disagreement can be a real change point.
            after = before - self.cp["sourceConflictPenalty"]
        else:
            neutral = 0.75
            after = before + (neutral - before) * self.cp["reliabilityDecayToNeutral"]
        after = clamp(after, self.cp["sourceReliabilityFloor"], self.cp["sourceReliabilityCeiling"])
        if round(after, 8) != round(before, 8):
            self.source_reliability[src] = after
            self.metrics["source_reliability_updates"] += 1
            self.emit("SOURCE_RELIABILITY_UPDATE", source=src, before=round(before, 6), after=round(after, 6))

    def _change_point_step(self, rec: dict[str, Any]) -> None:
        if rec["value"] == self.plan:
            self._calibrated_step(rec, change_point=True)
            return
        recent = [x for x in self.evidence if self.tick - x["tick"] <= self.cp["recentTicks"] and x["value"] == rec["value"]]
        sources = {x["source"] for x in recent}
        weighted = sum(x["confidence"] * self.source_reliability[x["source"]] for x in recent)
        same_source_count = Counter(x["source"] for x in recent)
        max_same = max(same_source_count.values()) if same_source_count else 0
        mean_same_conf = 0.0
        if max_same:
            best_source = max(same_source_count, key=same_source_count.get)
            vals = [x["confidence"] for x in recent if x["source"] == best_source]
            mean_same_conf = sum(vals) / len(vals)
        hard = rec["confidence"] >= self.cp["hardChangeConfidence"]
        corroborated = len(sources) >= self.cp["corroboratingSources"] and weighted >= self.cp["corroboratingScore"]
        persistent = max_same >= self.cp["sameSourcePersistence"] and mean_same_conf >= self.cp["sameSourceMinConfidence"]
        detected = hard or corroborated or persistent
        same_active_candidate = (
            self.last_change_candidate == rec["value"]
            and self.last_detected_cp_tick is not None
            and self.tick - self.last_detected_cp_tick <= self.policy["evidenceWindowTicks"]
        )
        if detected and not same_active_candidate:
            old_epoch = self.epoch_start
            # Keep the candidate evidence that justified the change point, but invalidate
            # older regime evidence so a previous real target cannot stay sticky.
            new_epoch = max(old_epoch, min(x["tick"] for x in recent))
            stale = [x for x in self.evidence if old_epoch <= x["tick"] < new_epoch]
            self.metrics["stale_evidence_invalidated"] += len(stale)
            self.epoch_start = new_epoch
            self.last_change_candidate = rec["value"]
            self.last_detected_cp_tick = self.tick
            self.metrics["change_points_detected"] += 1
            if rec["value"] != self.world_target:
                self.metrics["spurious_change_points"] += 1
            else:
                match = next((x for x in reversed(self.world_changes) if x["value"] == rec["value"] and x["detectedTick"] is None), None)
                if match is not None:
                    match["detectedTick"] = self.tick
                    self.metrics["true_change_points_detected"] += 1
                    self.metrics["change_point_detection_delay_ticks"] += self.tick - match["tick"]
            self.emit(
                "CHANGE_POINT",
                candidate=rec["value"],
                cause="HARD" if hard else "CORROBORATED" if corroborated else "PERSISTENT",
                oldEpoch=old_epoch,
                newEpoch=self.epoch_start,
                invalidated=len(stale),
                weighted=round(weighted, 6),
                sources=len(sources),
            )
        self._calibrated_step(rec, change_point=True)

    def _sequential_review(self) -> None:
        if self.mode != "SEQUENTIAL_A":
            return
        if self.tick % int(self.fixture["limits"]["sequentialReviewTicks"]) != 0:
            return
        obs = [x for x in self.evidence if x["tick"] <= self.tick]
        if not obs:
            return
        latest = max(obs, key=lambda x: (x["tick"], x["confidence"], x["source"]))
        if latest["value"] != self.plan:
            self._set_plan(latest["value"], "SEQUENTIAL_REVIEW")

    def _should_hold_commit(self) -> bool:
        if self.mode not in ("CALIBRATED_D", "CHANGEPOINT_E", "CHANGEPOINT_HOLD_F"):
            return False
        cp_mode = self.mode in ("CHANGEPOINT_E", "CHANGEPOINT_HOLD_F")
        scored = self._score_candidates(epoch_only=cp_mode, reliability=False)
        if not scored:
            return False
        plan_score = scored.get(self.plan, {"score": 0.0})["score"]
        best_other = max((v["score"] for k, v in scored.items() if k != self.plan), default=0.0)
        margin = abs(plan_score - best_other)
        threshold = self.policy["highConsequenceReviewScore"]
        ambiguous = margin < threshold and best_other > 0.20
        if self.mode == "CHANGEPOINT_HOLD_F" and self.last_detected_cp_tick is not None:
            ambiguous = ambiguous or (self.tick - self.last_detected_cp_tick <= self.cp["postChangeGraceTicks"])
        return ambiguous

    def _commit(self) -> None:
        if self._should_hold_commit():
            self.metrics["held_commits"] += 1
            self.metrics["deliberative_bursts"] += 1
            self.emit("COMMIT_HOLD", reason="AMBIGUOUS_EVIDENCE", plan=self.plan)
            return
        allowed, reason = self.guard.check()
        if not allowed:
            self.emit("COMMIT_BLOCKED", reason=reason, plan=self.plan)
            return
        self.metrics["actions_executed"] += 1
        bad = self.plan != self.world_target
        if bad:
            self.metrics["bad_commits"] += 1
        self.emit("COMMIT_EXECUTED", plan=self.plan, worldTarget=self.world_target, bad=bad)

    def run(self) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        self.emit("SIM_START", mode=self.mode, scenario=self.s["id"], authority="NONE")
        for self.tick in range(1, self.max_ticks + 1):
            for ev in self.events_by_tick.get(self.tick, []):
                kind = ev["kind"]
                if kind == "WORLD_TARGET_CHANGE":
                    self.world_target = int(ev["value"])
                    self.last_change_tick = self.tick
                    self.world_changes.append({"tick": self.tick, "value": self.world_target, "detectedTick": None})
                    self.emit("WORLD_TARGET_CHANGE", value=self.world_target)
                elif kind == "OBSERVATION":
                    self._observation(ev)
                elif kind == "MISSING_OBSERVATION":
                    self.metrics["reasoning_events"] += 1
                    self.metrics["uncertainty_activations"] += 1
                    self.emit("MISSING_OBSERVATION", source=ev.get("source"))
                elif kind == "REVOKE_PERMIT":
                    self.guard.revoked = True
                    self.emit("PERMIT_REVOKED")
                else:
                    raise ValueError(f"unknown event kind {kind}")
            self._sequential_review()
            if self.tick in self.commit_ticks:
                self._commit()
            self._update_delay()
        if self.mode in ("CHANGEPOINT_E", "CHANGEPOINT_HOLD_F"):
            self.metrics["missed_world_changes"] = sum(1 for x in self.world_changes if x["detectedTick"] is None)
        tp = sum(1 for x in self.observation_truth if x["truth"] and x["decision"])
        fp = sum(1 for x in self.observation_truth if not x["truth"] and x["decision"])
        fn = sum(1 for x in self.observation_truth if x["truth"] and not x["decision"])
        tn = sum(1 for x in self.observation_truth if not x["truth"] and not x["decision"])
        result = {
            "schema": "axm.change-point-evidence-invalidation-result/v0.28",
            "scenario": self.s["id"],
            "split": self.s.get("split", "HELD_OUT"),
            "mode": self.mode,
            "authority": "NONE",
            "canon": False,
            "metrics": dict(self.metrics),
            "confusion": {"TP": tp, "FP": fp, "FN": fn, "TN": tn},
            "final": {
                "plan": self.plan,
                "worldTarget": self.world_target,
                "correctFinalPlan": self.plan == self.world_target,
                "epochStart": self.epoch_start,
            },
            "sourceReliability": {k: round(v, 6) for k, v in sorted(self.source_reliability.items())},
        }
        semantic = {k: v for k, v in result.items() if k != "semanticDigest"}
        semantic["ledgerDigest"] = digest([{k: e[k] for k in ("seq", "tick", "kind", "payload")} for e in self.ledger])
        result["semanticDigest"] = digest(semantic)
        return result, self.ledger


def _h(seed: int, label: str, modulo: int) -> int:
    raw = hashlib.sha256(f"v0.28|{seed}|{label}".encode()).digest()
    return int.from_bytes(raw[:8], "big") % modulo


def _pick_target(seed: int, label: str, avoid: int) -> int:
    x = 1 + _h(seed, label, 9)
    if x == avoid:
        x = 1 + (x % 9)
    return x


def generate_scenario(seed: int, fixture: dict[str, Any], split: str) -> dict[str, Any]:
    families = fixture["heldoutGenerator"]["families"]
    fam = families[_h(seed, "family", len(families))]
    start = 1 + _h(seed, "start", 9)
    nxt = _pick_target(seed, "next", start)
    nxt2 = _pick_target(seed, "next2", nxt)
    max_ticks = 18 + _h(seed, "ticks", 3)
    c1 = round(0.34 + _h(seed, "c1", 31) / 100, 2)
    c2 = round(0.48 + _h(seed, "c2", 31) / 100, 2)
    c3 = round(0.72 + _h(seed, "c3", 25) / 100, 2)
    events: list[dict[str, Any]] = []
    commits = [7, 11, max_ticks]

    def o(at: int, src: str, val: int, conf: float) -> dict[str, Any]:
        return {"at": at, "kind": "OBSERVATION", "source": src, "value": val, "confidence": clamp(round(conf, 2), 0.05, 0.99)}

    if fam == "stable-noise":
        events = [o(3, "cam-a", nxt, c1), o(6, "cam-b", start, c3)]
    elif fam == "real-change-weak":
        events = [{"at": 4, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(4, "cam-a", nxt, c1), o(6, "cam-a", nxt, min(c1 + .05, .70)), o(8, "cam-a", nxt, min(c1 + .09, .74))]
    elif fam == "real-change-corroborated":
        events = [{"at": 4, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(4, "cam-a", nxt, c2), o(5, "cam-b", nxt, min(c2 + .08, .88))]
    elif fam == "real-change-strong":
        events = [{"at": 4, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(4, "cam-a", nxt, max(.93, c3))]
    elif fam == "rapid-flap":
        events = [{"at": 3, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(3, "cam-a", nxt, .95), o(4, "cam-b", nxt, .78), {"at": 6, "kind": "WORLD_TARGET_CHANGE", "value": nxt2}, o(6, "cam-c", nxt2, .91), o(7, "cam-d", nxt2, .76)]
    elif fam == "stale-prior-conflict":
        events = [{"at": 3, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(3, "cam-a", nxt, .92), o(4, "cam-b", nxt, .80), {"at": 8, "kind": "WORLD_TARGET_CHANGE", "value": nxt2}, o(8, "cam-c", nxt2, .74), o(9, "cam-d", nxt2, .72)]
    elif fam == "persistent-false-one-source":
        events = [o(3, "cam-a", nxt, c1), o(4, "cam-a", nxt, c1+.03), o(5, "cam-a", nxt, c1+.06), o(6, "cam-a", nxt, c1+.08), o(9, "cam-b", start, .84)]
    elif fam == "high-confidence-false":
        events = [o(4, "cam-a", nxt, .94 + _h(seed, "hf", 5)/100), o(8, "cam-b", start, .84)]
    elif fam == "late-corroboration":
        events = [{"at": 3, "kind": "WORLD_TARGET_CHANGE", "value": nxt}, o(3, "cam-a", nxt, c1), o(10, "cam-b", nxt, c2+.12)]
    elif fam == "source-conflict":
        events = [o(3, "cam-a", nxt, .68), o(4, "cam-b", nxt2, .71), o(7, "cam-c", start, .82)]
    elif fam == "missing-then-change":
        events = [{"at":3,"kind":"MISSING_OBSERVATION","source":"cam-a"},{"at":5,"kind":"WORLD_TARGET_CHANGE","value":nxt},o(6,"cam-a",nxt,c1),o(8,"cam-b",nxt,c2)]
    elif fam == "sensor-recovery":
        events = [o(3,"cam-a",nxt,.79),o(4,"cam-b",start,.76),o(7,"cam-a",start,.83)]
    elif fam == "reliability-regime-shift":
        events = [o(3,"cam-a",start,.90),o(4,"cam-b",start,.82),{"at":7,"kind":"WORLD_TARGET_CHANGE","value":nxt},o(7,"cam-a",nxt2,.87),o(8,"cam-b",nxt,c1+.10),o(9,"cam-c",nxt,c2)]
    elif fam == "synchronized-false-corroboration":
        events = [o(4,"cam-a",nxt,.73),o(5,"cam-b",nxt,.75),o(9,"cam-c",start,.85)]
    elif fam == "irreversible-ambiguity":
        events = [{"at":4,"kind":"WORLD_TARGET_CHANGE","value":nxt},o(4,"cam-a",nxt,.57),o(5,"cam-b",start,.55),o(8,"cam-c",nxt,.59)]
        commits = [6, 10, max_ticks]
    elif fam == "alternating-noise":
        events = [o(3,"cam-a",nxt,.58),o(4,"cam-b",nxt2,.60),o(5,"cam-a",nxt,.61),o(6,"cam-b",nxt2,.63),o(9,"cam-c",start,.80)]
    else:
        raise AssertionError(fam)
    return {
        "id": f"heldout-{seed}-{fam}",
        "split": split,
        "seed": seed,
        "family": fam,
        "startTarget": start,
        "maxTicks": max_ticks,
        "permit": "VALID",
        "commitTicks": commits,
        "events": events,
    }


def generate_heldout_scenario(seed: int, fixture: dict[str, Any]) -> dict[str, Any]:
    return generate_scenario(seed, fixture, "HELD_OUT")


def generate_development_scenario(seed: int, fixture: dict[str, Any]) -> dict[str, Any]:
    return generate_scenario(seed, fixture, "DEVELOPMENT")


def all_scenarios(fixture: dict[str, Any]) -> list[dict[str, Any]]:
    return (
        list(fixture["scenarios"])
        + [generate_development_scenario(int(x), fixture) for x in fixture.get("developmentSeeds", [])]
        + [generate_heldout_scenario(int(x), fixture) for x in fixture["heldoutSeeds"]]
    )


def run_once(fixture: dict[str, Any], scenario: dict[str, Any], mode: str):
    return Simulator(fixture, scenario, mode).run()


def _brier_from_confusion(c: dict[str, int]) -> float:
    # Coarse deterministic decision-calibration proxy: yes/no decision error rate.
    n = sum(c.values())
    return (c["FP"] + c["FN"]) / n if n else 0.0


def validate_ledger(events: list[dict[str, Any]]) -> list[str]:
    errors = []
    for i, e in enumerate(events, 1):
        if e.get("seq") != i:
            errors.append(f"seq:{i}")
        expect = digest({k: e[k] for k in ("seq", "tick", "kind", "payload")})
        if expect != e.get("eventDigest"):
            errors.append(f"digest:{i}")
    return errors


def benchmark(scenarios_path: Path, output: Path, repeat: int = 3) -> dict[str, Any]:
    fixture = json.loads(scenarios_path.read_text())
    output.mkdir(parents=True, exist_ok=True)
    scenarios = all_scenarios(fixture)
    aggregate: dict[str, dict[str, Any]] = {}
    semantic_repeatable = True
    ledger_errors: list[str] = []
    raw: list[dict[str, Any]] = []
    ledgers: dict[str, Any] = {}
    for mode in MODES:
        agg = Counter()
        confusion = Counter()
        family = defaultdict(lambda: Counter())
        for s in scenarios:
            reps = []
            first_events = None
            for r in range(repeat):
                result, events = run_once(fixture, s, mode)
                reps.append(result["semanticDigest"])
                if first_events is None:
                    first_events = events
                    errors = validate_ledger(events)
                    if errors:
                        ledger_errors.extend([f"{s['id']}:{mode}:{x}" for x in errors])
                    ledgers[f"{s['id']}::{mode}"] = {
                        "eventCount": len(events),
                        "ledgerDigest": digest(events),
                    }
                    raw.append(result)
                    if s.get("split") == "HELD_OUT":
                        m = result["metrics"]
                        agg["correct_final_plans"] += int(result["final"]["correctFinalPlan"])
                        for key in (
                            "false_positive_preemptions","false_negative_delay_ticks","bad_commits","held_commits",
                            "reasoning_events","change_points_detected","spurious_change_points","stale_evidence_invalidated",
                            "true_change_points_detected","missed_world_changes","change_point_detection_delay_ticks"
                        ):
                            agg[key] += int(m.get(key, 0))
                        confusion.update(result["confusion"])
                        fam = s.get("family", "unknown")
                        family[fam]["n"] += 1
                        family[fam]["correct"] += int(result["final"]["correctFinalPlan"])
                        family[fam]["bad_commits"] += int(m.get("bad_commits", 0))
                        family[fam]["fp"] += int(m.get("false_positive_preemptions", 0))
                else:
                    pass
            if len(set(reps)) != 1:
                semantic_repeatable = False
        cdict = {k: int(confusion[k]) for k in ("TP","FP","FN","TN")}
        aggregate[mode] = {
            **{k: int(v) for k, v in agg.items()},
            "confusion": cdict,
            "brierProxy": round(_brier_from_confusion(cdict), 6),
            "families": {k: dict(v) for k, v in sorted(family.items())},
        }
    bundle = {
        "schema": "axm.change-point-evidence-invalidation-benchmark/v0.28",
        "challenge": fixture["challenge"],
        "modes": list(MODES),
        "primaryModes": list(PRIMARY_MODES),
        "posthocModes": list(POSTHOC_MODES),
        "scenarioCount": len(scenarios),
        "developmentScenarioCount": len(fixture.get("developmentSeeds", [])),
        "heldoutScenarioCount": len(fixture["heldoutSeeds"]),
        "repeat": repeat,
        "aggregate": aggregate,
        "repeatability": {"allRepeatable": semantic_repeatable, "ledgerValidationErrors": ledger_errors},
    }
    (output / "raw-metrics.json").write_text(json.dumps(raw, indent=2, sort_keys=True) + "\n")
    (output / "repeatability.json").write_text(json.dumps(bundle["repeatability"], indent=2, sort_keys=True) + "\n")
    (output / "ledger-digests.json").write_text(json.dumps(ledgers, indent=2, sort_keys=True) + "\n")
    (output / "probe-summary.json").write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n")
    return bundle


def build_summary(bundle: dict[str, Any], output: Path) -> None:
    a = bundle["aggregate"]
    lines = [
        "# v0.28 change-point evidence invalidation benchmark",
        "",
        f"Challenge: `{bundle['challenge']}`",
        "",
        "Primary table is the deterministic HELD_OUT distribution for the modes frozen before the fresh held-out seeds were inspected. It is simulator evidence, not a claim of general superiority.",
        "",
        "| Mode | correct final plans | false-positive preempts | false-negative delay | bad commits | held commits | CP true | CP spurious | CP missed | CP delay | stale invalidated | reasoning events |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for mode in PRIMARY_MODES:
        x = a[mode]
        lines.append(
            f"| {mode} | {x.get('correct_final_plans',0)}/{bundle['heldoutScenarioCount']} | {x.get('false_positive_preemptions',0)} | {x.get('false_negative_delay_ticks',0)} | {x.get('bad_commits',0)} | {x.get('held_commits',0)} | {x.get('true_change_points_detected',0)} | {x.get('spurious_change_points',0)} | {x.get('missed_world_changes',0)} | {x.get('change_point_detection_delay_ticks',0)} | {x.get('stale_evidence_invalidated',0)} | {x.get('reasoning_events',0)} |"
        )
    lines += [
        "",
        "## Post-hoc ablation",
        "",
        "`CHANGEPOINT_HOLD_F` was added after the fresh held-out distribution had been inspected. Its numbers are shown only as a post-hoc mechanism probe and are **not** independent held-out evidence.",
        "",
        "| Mode | correct final plans | bad commits | held commits | CP true | CP spurious | CP missed |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for mode in POSTHOC_MODES:
        x = a[mode]
        lines.append(f"| {mode} | {x.get('correct_final_plans',0)}/{bundle['heldoutScenarioCount']} | {x.get('bad_commits',0)} | {x.get('held_commits',0)} | {x.get('true_change_points_detected',0)} | {x.get('spurious_change_points',0)} | {x.get('missed_world_changes',0)} |")
    lines += ["", "## Confusion matrices", ""]
    for mode in MODES:
        c = a[mode]["confusion"]
        lines.append(f"- {mode}: TP={c['TP']} FP={c['FP']} FN={c['FN']} TN={c['TN']} ; decision-error proxy={a[mode]['brierProxy']}")
    lines += [
        "",
        "## Boundary",
        "",
        "- Reasoning-mode selector authority is `NONE`.",
        "- Change-point detection and source reliability are evidence-processing signals only.",
        "- Every simulated world-facing commit crosses the same `ExecutionGuard`.",
        "- No result installs, merges, promotes, or changes CANON.",
        "- Negative cases and families are retained.",
        "",
        "AXM pokes and logs.",
    ]
    text = "\n".join(lines) + "\n"
    (output / "BENCHMARK-SUMMARY.md").write_text(text)
    return_packet = {
        "schema": "axm.return-packet/v0.28",
        "challenge": bundle["challenge"],
        "status": "OBSERVED_SIMULATOR_RESULT",
        "heldoutScenarioCount": bundle["heldoutScenarioCount"],
        "repeatability": bundle["repeatability"],
        "aggregateDigest": digest(bundle["aggregate"]),
        "authority": "NONE",
        "canon": False,
    }
    (output / "return-packet.json").write_text(json.dumps(return_packet, indent=2, sort_keys=True) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenarios", type=Path, default=Path(__file__).with_name("scenarios.json"))
    ap.add_argument("--output", type=Path, default=Path(__file__).with_name("artifacts"))
    ap.add_argument("--repeat", type=int, default=3)
    args = ap.parse_args()
    bundle = benchmark(args.scenarios, args.output, args.repeat)
    build_summary(bundle, args.output)
    print(canonical({"challenge": bundle["challenge"], "heldout": bundle["heldoutScenarioCount"], "repeatability": bundle["repeatability"], "aggregate": bundle["aggregate"]}))


if __name__ == "__main__":
    main()
