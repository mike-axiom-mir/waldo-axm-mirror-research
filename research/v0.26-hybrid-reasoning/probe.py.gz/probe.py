#!/usr/bin/env python3
"""AXM v0.26 adaptive reasoning topology A/B/C probe.

A = fixed sequential reasoning
B = always-coupled event-driven reasoning
C = adaptive hybrid reasoning that distinguishes contradiction, uncertainty,
    and stable state before selecting a topology.

This is a deterministic bounded simulator. It does not claim consciousness,
free thought, emergence, general intelligence, or execution authority.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

SCHEMA = "axm.adaptive-reasoning-abc-result/v0.26"
CHALLENGE = "REASONING_MODE_IS_NOT_EXECUTION_AUTHORITY"
AUTHORITY = "NONE"
ENVIRONMENT = "SIM-ROOM-A"
CAPABILITY = "MOVE_SIM_ARM"
SCOPE = "EXECUTE_IN_ENVIRONMENT"

MODES = ("SEQUENTIAL_A", "COUPLED_B", "HYBRID_C")
TOPOLOGIES = ("SEQUENTIAL", "COUPLED", "UNCERTAINTY")


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def sha256(value: Any) -> str:
    raw = value if isinstance(value, bytes) else canonical(value)
    return "sha256:" + hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class Permit:
    present: bool
    environment: str = ""
    capability: str = ""
    scope: str = ""
    revocable: bool = False


@dataclass
class Plan:
    plan_id: str
    target: int
    actions: list[dict[str, int | str]]
    created_at: int
    status: str = "PENDING"
    actions_executed: int = 0


class ExecutionGuard:
    def __init__(self, scenario: dict[str, Any], limits: dict[str, int], metrics: dict[str, Any]) -> None:
        mode = scenario.get("permit", "VALID")
        if mode == "ABSENT":
            self.permit = Permit(False)
        else:
            env = "SIM-ROOM-B" if mode == "WRONG_ENVIRONMENT" else ENVIRONMENT
            cap = "WRITE_SIM_FILE" if mode == "WRONG_CAPABILITY" else CAPABILITY
            self.permit = Permit(True, env, cap, SCOPE, True)
        self.actuator_route = bool(scenario.get("actuatorRoute", True))
        self.revoked = False
        self.limits = limits
        self.metrics = metrics

    def revoke(self) -> None:
        if self.permit.present and self.permit.revocable:
            self.revoked = True

    def check(self) -> tuple[str, str]:
        m = self.metrics
        m["execution_permit_checks"] += 1
        if not self.actuator_route:
            m["holds"] += 1
            return "HOLD", "ACTUATOR_ROUTE_ABSENT"
        if not self.permit.present:
            m["holds"] += 1
            return "HOLD", "EXECUTION_PERMIT_ABSENT"
        if self.revoked:
            m["authority_violations_attempted"] += 1
            m["authority_violations_refused"] += 1
            return "REFUSED", "EXECUTION_PERMIT_REVOKED"
        if not self.permit.revocable or self.permit.scope != SCOPE:
            m["authority_violations_attempted"] += 1
            m["authority_violations_refused"] += 1
            return "REFUSED", "EXECUTION_SCOPE_INVALID"
        if self.permit.environment != ENVIRONMENT:
            m["authority_violations_attempted"] += 1
            m["authority_violations_refused"] += 1
            return "REFUSED", "ENVIRONMENT_SCOPE_MISMATCH"
        if self.permit.capability != CAPABILITY:
            m["authority_violations_attempted"] += 1
            m["authority_violations_refused"] += 1
            return "REFUSED", "CAPABILITY_SCOPE_MISMATCH"
        if m["actions_executed"] >= self.limits["maxActions"]:
            m["holds"] += 1
            return "HOLD", "ACTION_BUDGET_EXHAUSTED"
        return "READY", "EXACT_LOCAL_ENVELOPE_MATCH"


class Ledger:
    def __init__(self, mode: str, scenario_id: str) -> None:
        self.mode = mode
        self.scenario_id = scenario_id
        self.events: list[dict[str, Any]] = []
        self.version = 0

    def append(self, at: int, emitter: str, kind: str, payload: dict[str, Any], parents: list[int] | None = None, changes_state: bool = False) -> int:
        if changes_state:
            self.version += 1
        seq = len(self.events) + 1
        p = sorted(set(parents or []))
        if any(x <= 0 or x >= seq for x in p):
            raise ValueError("causal parent must reference earlier event")
        event = {
            "seq": seq,
            "logicalTime": at,
            "emitter": emitter,
            "kind": kind,
            "causalParents": p,
            "stateVersion": self.version,
            "payload": payload,
        }
        prior = self.events[-1]["eventDigest"] if self.events else "GENESIS"
        event["stateDigest"] = sha256({
            "mode": self.mode,
            "scenario": self.scenario_id,
            "version": self.version,
            "prior": prior,
            "event": event,
        })
        event["eventDigest"] = sha256(event)
        self.events.append(event)
        return seq

    def receipt(self) -> dict[str, Any]:
        valid = all(all(0 < p < e["seq"] for p in e["causalParents"]) for e in self.events)
        return {
            "eventCount": len(self.events),
            "validCausalReferences": valid,
            "ledgerDigest": sha256(self.events),
            "completeness": 1.0,
        }


class Simulator:
    def __init__(self, fixture: dict[str, Any], scenario: dict[str, Any], mode: str) -> None:
        self.fixture = fixture
        self.scenario = copy.deepcopy(scenario)
        self.mode = mode
        self.limits = fixture["limits"]
        self.now = 0
        self.position = int(scenario["start"])
        self.true_target = int(scenario["target"])
        self.observed_target: int | None = self.true_target
        self.noise_value: int | None = None
        self.observation_missing = False
        self.obstruction: int | None = None
        self.placements: list[int] = []
        self.wrong_placements = 0
        self.plan_counter = 0
        self.plan: Plan | None = None
        self.topology = "SEQUENTIAL"
        self.topology_since = 0
        self.last_mode_switch = -999
        self.uncertainty_since: int | None = None
        self.pending_uncertain_signal: dict[str, Any] | None = None
        self.disturbances = {int(x["at"]): copy.deepcopy(x) for x in scenario.get("disturbances", [])}
        self.metrics = {
            "contradiction_at": None,
            "correction_at": None,
            "cancel_at": None,
            "contradictionToCorrectionTicks": None,
            "contradictionToCancelTicks": None,
            "unnecessary_actions": 0,
            "actions_later_repaired": 0,
            "reasoning_invocations": 0,
            "events": 0,
            "builder_proposals": 0,
            "builder_proposals_revised_before_execution": 0,
            "witness_disagreements": 0,
            "gap_openings": 0,
            "holds": 0,
            "actions_executed": 0,
            "execution_permit_checks": 0,
            "authority_violations_attempted": 0,
            "authority_violations_refused": 0,
            "false_contradictions": 0,
            "mode_switches": 0,
            "coupled_activations": 0,
            "uncertainty_activations": 0,
            "uncertainty_resolutions": 0,
            "sequential_ticks": 0,
            "coupled_ticks": 0,
            "uncertainty_ticks": 0,
            "prevented_false_preemptions": 0,
            "deferred_place_actions": 0,
            "starvation": False,
            "timeout": False,
        }
        self.guard = ExecutionGuard(self.scenario, self.limits, self.metrics)
        self.ledger = Ledger(mode, scenario["id"])
        self.next_sequential_review = self.limits["sequentialReviewTicks"]
        self.last_observation = self.observe()
        self.start_seq = self.ledger.append(0, "PERCEPTION", "RUN_STARTED", {"mode": mode, "seed": scenario["seed"], "authority": AUTHORITY}, changes_state=True)
        self.create_plan(self.last_observation["observedTarget"], [self.start_seq])

    def invoke(self, role: str) -> None:
        self.metrics["reasoning_invocations"] += 1
        self.ledger.append(self.now, role, "ROLE_INVOKED", {"topology": self.topology})

    def observe(self) -> dict[str, Any]:
        target = None if self.observation_missing else (self.noise_value if self.noise_value is not None else self.true_target)
        self.observed_target = target
        return {"position": self.position, "observedTarget": target, "obstruction": self.obstruction}

    def create_plan(self, target: int | None, parents: list[int]) -> None:
        self.invoke("BUILDER")
        if target is None:
            self.metrics["holds"] += 1
            self.ledger.append(self.now, "BUILDER", "HOLD", {"reason": "TARGET_EVIDENCE_MISSING"}, parents, True)
            return
        self.plan_counter += 1
        step = 1 if target >= self.position else -1
        actions = [{"kind": "MOVE", "delta": step} for _ in range(abs(target - self.position))]
        actions.append({"kind": "PLACE", "delta": 0})
        self.plan = Plan(f"{self.mode.lower()}-plan-{self.plan_counter}", int(target), actions, self.now)
        self.metrics["builder_proposals"] += 1
        self.ledger.append(self.now, "BUILDER", "PROPOSAL_CREATED", {
            "planId": self.plan.plan_id,
            "target": target,
            "actionCount": len(actions),
            "topology": self.topology,
        }, parents, True)

    def switch_topology(self, target: str, reason: str, parent: int) -> None:
        if self.mode != "HYBRID_C":
            self.topology = "COUPLED" if self.mode == "COUPLED_B" else "SEQUENTIAL"
            return
        if target == self.topology:
            return
        # Cooldown prevents noise-driven thrashing, but hard contradictions may
        # still escalate immediately.
        hard = reason in {"HARD_TARGET_CONTRADICTION", "OBSTRUCTION_PRESENT", "PERMIT_REVOKED"}
        if not hard and self.now - self.last_mode_switch < self.limits["modeCooldownTicks"]:
            return
        old = self.topology
        self.topology = target
        self.topology_since = self.now
        self.last_mode_switch = self.now
        self.metrics["mode_switches"] += 1
        if target == "COUPLED":
            self.metrics["coupled_activations"] += 1
        elif target == "UNCERTAINTY":
            self.metrics["uncertainty_activations"] += 1
        self.ledger.append(self.now, "MODE_SELECTOR", "REASONING_TOPOLOGY_CHANGED", {
            "from": old, "to": target, "reason": reason, "authority": AUTHORITY
        }, [parent], True)

    def classify_signal(self, disturbance: dict[str, Any], observation: dict[str, Any]) -> tuple[str, str]:
        kind = disturbance["kind"]
        if kind == "TARGET_SHIFT":
            return "HARD_CONTRADICTION", "concrete target changed"
        if kind == "AMBIGUOUS_TARGET_CHANGE":
            return "UNCERTAINTY", "low-confidence target change may be real or noisy"
        if kind == "OBSTRUCTION":
            return "HARD_CONTRADICTION", "physical obstruction appeared"
        if kind == "MISSING_OBSERVATION":
            return "UNCERTAINTY", "evidence absent but prior grounded plan not contradicted"
        if kind == "NOISY_OBSERVATION":
            return "UNCERTAINTY", "single noisy observation requires persistence/corroboration"
        if kind in {"CLEAR_NOISE", "RESTORE_OBSERVATION", "CLEAR_OBSTRUCTION"}:
            return "RESOLUTION", "uncertainty or obstruction resolved"
        if kind == "REVOKE_PERMIT":
            return "AUTHORITY_EVENT", "execution permit revoked"
        return "STABLE", "no contradiction"

    def cancel_plan(self, reason: str, parent: int) -> None:
        if self.plan is None or self.plan.status != "PENDING":
            return
        if self.plan.actions_executed == 0:
            self.metrics["builder_proposals_revised_before_execution"] += 1
        self.plan.status = "CANCELLED"
        if self.metrics["cancel_at"] is None:
            self.metrics["cancel_at"] = self.now
        self.ledger.append(self.now, "WITNESS", "PENDING_PLAN_CANCELLED", {
            "planId": self.plan.plan_id, "reason": reason
        }, [parent], True)

    def begin_repair(self, target: int | None, parent: int) -> None:
        self.invoke("GAP")
        self.metrics["gap_openings"] += 1
        g = self.ledger.append(self.now, "GAP", "GAP_OPENED", {"need": "CURRENT_GROUNDED_TARGET"}, [parent])
        self.invoke("PREDICTION")
        p = self.ledger.append(self.now, "PREDICTION", "OUTCOME_REEVALUATED", {"target": target}, [parent])
        self.invoke("REPAIR")
        if self.metrics["correction_at"] is None:
            self.metrics["correction_at"] = self.now
        c = self.ledger.append(self.now, "REPAIR", "CORRECTION_BEGAN", {"target": target}, [g, p], True)
        if target is None:
            self.metrics["holds"] += 1
            self.ledger.append(self.now, "REPAIR", "HOLD", {"reason": "TARGET_STILL_UNCERTAIN"}, [c], True)
            return
        self.create_plan(target, [c])

    def apply_disturbance(self, item: dict[str, Any]) -> int:
        kind = item["kind"]
        if kind == "TARGET_SHIFT":
            self.true_target = int(item["value"])
        elif kind == "AMBIGUOUS_TARGET_CHANGE":
            # A real target change arriving through a low-confidence channel.
            # The observed value is correct, but the hybrid selector cannot know
            # that without confirmation.
            self.true_target = int(item["value"])
            self.noise_value = int(item["value"])
        elif kind == "NOISY_OBSERVATION":
            self.noise_value = int(item["value"])
        elif kind == "CLEAR_NOISE":
            self.noise_value = None
        elif kind == "MISSING_OBSERVATION":
            self.observation_missing = True
        elif kind == "RESTORE_OBSERVATION":
            self.observation_missing = False
        elif kind == "OBSTRUCTION":
            self.obstruction = int(item["value"])
        elif kind == "CLEAR_OBSTRUCTION":
            self.obstruction = None
        elif kind == "REVOKE_PERMIT":
            self.guard.revoke()
        else:
            raise ValueError(kind)
        obs = self.observe()
        if self.plan is not None and self.plan.status == "PENDING":
            apparent_conflict = (
                obs["observedTarget"] is None
                or obs["observedTarget"] != self.plan.target
                or obs["obstruction"] is not None
            )
            if apparent_conflict and self.metrics["contradiction_at"] is None:
                # Time contradictory/insufficient evidence became available,
                # independent of when a topology chooses to react to it.
                self.metrics["contradiction_at"] = self.now
        seq = self.ledger.append(self.now, "PERCEPTION", "ENVIRONMENT_UPDATE", {
            "disturbance": item, "observation": obs
        }, changes_state=True)
        return seq

    def coupled_response(self, signal: str, obs: dict[str, Any], parent: int, *, always: bool = False) -> None:
        # Always-coupled B conflates missing/noisy evidence with contradiction.
        if always and signal == "UNCERTAINTY":
            signal = "HARD_CONTRADICTION"
        if signal != "HARD_CONTRADICTION":
            return
        self.invoke("WITNESS")
        self.metrics["witness_disagreements"] += 1
        if self.metrics["contradiction_at"] is None:
            self.metrics["contradiction_at"] = self.now
        if obs["observedTarget"] is not None and obs["observedTarget"] != self.true_target:
            self.metrics["false_contradictions"] += 1
        w = self.ledger.append(self.now, "WITNESS", "CONTRADICTION_DETECTED", {
            "planId": None if self.plan is None else self.plan.plan_id,
            "observation": obs,
        }, [parent])
        self.cancel_plan("WITNESS_CONTRADICTION", w)
        self.begin_repair(obs["observedTarget"], w)

    def hybrid_response(self, item: dict[str, Any], signal: str, obs: dict[str, Any], parent: int) -> None:
        if signal == "HARD_CONTRADICTION":
            self.switch_topology("COUPLED", "OBSTRUCTION_PRESENT" if item["kind"] == "OBSTRUCTION" else "HARD_TARGET_CONTRADICTION", parent)
            self.coupled_response(signal, obs, parent)
            return
        if signal == "UNCERTAINTY":
            self.uncertainty_since = self.now
            self.pending_uncertain_signal = {"kind": item["kind"], "obs": copy.deepcopy(obs), "seq": parent}
            self.switch_topology("UNCERTAINTY", "EVIDENCE_MISSING" if item["kind"] == "MISSING_OBSERVATION" else "NOISY_SINGLE_OBSERVATION", parent)
            self.ledger.append(self.now, "OPINION", "UNCERTAINTY_RECORDED", {
                "kind": item["kind"],
                "policy": "DO_NOT_TREAT_ABSENCE_OR_SINGLE_NOISE_AS_CONTRADICTION",
                "authority": AUTHORITY,
            }, [parent])
            return
        if signal == "RESOLUTION":
            if self.topology == "UNCERTAINTY":
                self.metrics["uncertainty_resolutions"] += 1
                if self.pending_uncertain_signal and self.pending_uncertain_signal["kind"] == "NOISY_OBSERVATION":
                    self.metrics["prevented_false_preemptions"] += 1
                # If restored evidence actually contradicts the plan, escalate.
                target = obs["observedTarget"]
                plan_target = None if self.plan is None else self.plan.target
                if target is not None and plan_target is not None and target != plan_target:
                    self.switch_topology("COUPLED", "RESOLVED_EVIDENCE_CONTRADICTS_PLAN", parent)
                    self.coupled_response("HARD_CONTRADICTION", obs, parent)
                else:
                    self.switch_topology("SEQUENTIAL", "UNCERTAINTY_RESOLVED", parent)
                self.pending_uncertain_signal = None
                self.uncertainty_since = None
            elif item["kind"] == "CLEAR_OBSTRUCTION" and self.plan is None:
                self.switch_topology("SEQUENTIAL", "OBSTRUCTION_CLEARED", parent)
            return
        if signal == "AUTHORITY_EVENT":
            self.switch_topology("COUPLED", "PERMIT_REVOKED", parent)
            self.ledger.append(self.now, "EXECUTION_CONTROL", "PERMIT_REVOKED", {"revoked": True}, [parent], True)

    def maybe_sequential_review(self) -> None:
        if self.mode != "SEQUENTIAL_A":
            return
        if self.now < self.next_sequential_review:
            return
        self.next_sequential_review += self.limits["sequentialReviewTicks"]
        self.invoke("PERCEPTION")
        obs = self.observe()
        seq = self.ledger.append(self.now, "PERCEPTION", "SEQUENTIAL_REVIEW", obs)
        if self.plan is None:
            if obs["observedTarget"] is not None:
                self.create_plan(obs["observedTarget"], [seq])
            return
        if self.plan.status == "EXECUTED":
            correct = bool(self.placements and self.placements[-1] == self.true_target)
            if not correct and obs["observedTarget"] is not None:
                if self.metrics["correction_at"] is None:
                    self.metrics["correction_at"] = self.now
                self.create_plan(obs["observedTarget"], [seq])
            return
        if self.plan.status != "PENDING":
            return
        contradiction = (
            obs["observedTarget"] is None
            or obs["observedTarget"] != self.plan.target
            or obs["obstruction"] is not None
        )
        if contradiction:
            self.invoke("WITNESS")
            self.metrics["witness_disagreements"] += 1
            if self.metrics["contradiction_at"] is None:
                self.metrics["contradiction_at"] = self.now
            w = self.ledger.append(self.now, "WITNESS", "CONTRADICTION_DETECTED", {"observation": obs}, [seq])
            self.cancel_plan("SEQUENTIAL_REVIEW_CONTRADICTION", w)
            self.begin_repair(obs["observedTarget"], w)

    def action_ready(self) -> bool:
        return (
            self.plan is not None
            and self.plan.status == "PENDING"
            and bool(self.plan.actions)
            and self.now >= self.plan.created_at + self.limits["planCommitDelayTicks"]
        )

    def execute_one(self) -> None:
        if not self.action_ready():
            return
        action = self.plan.actions[0]
        # Hybrid uncertainty preserves a grounded existing plan, but refuses to
        # commit the irreversible-ish PLACE edge until evidence is restored.
        if self.mode == "HYBRID_C" and self.topology == "UNCERTAINTY" and action["kind"] == "PLACE":
            self.metrics["deferred_place_actions"] += 1
            self.ledger.append(self.now, "EXECUTION_CONTROL", "PLACE_DEFERRED_UNDER_UNCERTAINTY", {
                "planId": self.plan.plan_id, "authority": AUTHORITY
            })
            return

        outcome, reason = self.guard.check()
        if outcome != "READY":
            self.plan.status = outcome
            self.ledger.append(self.now, "EXECUTION_CONTROL", outcome, {
                "reason": reason, "planId": self.plan.plan_id
            }, changes_state=True)
            return

        before = self.position
        if action["kind"] == "MOVE":
            candidate = self.position + int(action["delta"])
            if self.obstruction is not None and candidate == self.obstruction:
                result = "BLOCKED"
                # Preserve action for retry after obstruction clear.
                self.metrics["unnecessary_actions"] += 1
            else:
                self.position = candidate
                result = "MOVED"
                self.plan.actions.pop(0)
                self.plan.actions_executed += 1
                self.metrics["actions_executed"] += 1
                if self.plan.target != self.true_target:
                    self.metrics["unnecessary_actions"] += 1
        else:
            self.placements.append(self.position)
            self.plan.actions.pop(0)
            self.plan.actions_executed += 1
            self.metrics["actions_executed"] += 1
            if self.position == self.true_target:
                result = "PLACED_CORRECT"
            else:
                result = "PLACED_WRONG"
                self.wrong_placements += 1
                self.metrics["unnecessary_actions"] += 1

        seq = self.ledger.append(self.now, "EXECUTION_CONTROL", "ACTION_RESULT", {
            "planId": self.plan.plan_id,
            "action": action,
            "before": before,
            "after": self.position,
            "trueTarget": self.true_target,
            "result": result,
        }, changes_state=True)
        if result == "BLOCKED":
            if self.mode == "COUPLED_B":
                self.coupled_response("HARD_CONTRADICTION", self.observe(), seq, always=True)
            elif self.mode == "HYBRID_C":
                self.switch_topology("COUPLED", "OBSTRUCTION_PRESENT", seq)
                self.coupled_response("HARD_CONTRADICTION", self.observe(), seq)

    def recover_if_plan_cancelled(self) -> None:
        if self.plan is not None and self.plan.status == "CANCELLED":
            # begin_repair normally creates replacement immediately; only leave
            # cancelled plan if evidence was absent.
            return
        if self.plan is None:
            obs = self.observe()
            if obs["observedTarget"] is not None:
                self.create_plan(obs["observedTarget"], [len(self.ledger.events)])

    def run(self) -> dict[str, Any]:
        if self.mode == "COUPLED_B":
            self.topology = "COUPLED"
        for tick in range(1, self.limits["maxLogicalTicks"] + 1):
            self.now = tick
            if self.topology == "SEQUENTIAL":
                self.metrics["sequential_ticks"] += 1
            elif self.topology == "COUPLED":
                self.metrics["coupled_ticks"] += 1
            else:
                self.metrics["uncertainty_ticks"] += 1

            item = self.disturbances.get(tick)
            if item:
                parent = self.apply_disturbance(item)
                obs = self.observe()
                signal, _detail = self.classify_signal(item, obs)
                if self.mode == "COUPLED_B":
                    if signal == "AUTHORITY_EVENT":
                        self.ledger.append(self.now, "EXECUTION_CONTROL", "PERMIT_REVOKED", {"revoked": True}, [parent], True)
                    else:
                        self.coupled_response(signal, obs, parent, always=True)
                elif self.mode == "HYBRID_C":
                    self.hybrid_response(item, signal, obs, parent)

            self.maybe_sequential_review()

            # Coupled/hybrid can react to persistent uncertainty after grace.
            if self.mode == "HYBRID_C" and self.topology == "UNCERTAINTY" and self.uncertainty_since is not None:
                age = self.now - self.uncertainty_since
                if age > self.limits["uncertaintyGraceTicks"] and self.observation_missing:
                    self.ledger.append(self.now, "MODE_SELECTOR", "UNCERTAINTY_PERSISTS", {
                        "age": age, "decision": "PRESERVE_GROUNDED_PLAN_BUT_DEFER_PLACE"
                    })
                # Do not escalate solely due to missing evidence.
            self.execute_one()

            # If a plan completed with wrong placement, all modes can observe
            # outcome; coupled/hybrid react immediately, sequential on next review.
            if self.plan is not None and not self.plan.actions and self.plan.status == "PENDING":
                self.plan.status = "EXECUTED"
                if self.placements and self.placements[-1] == self.true_target:
                    # Do not stop if a known future disturbance remains.
                    if not any(t > tick for t in self.disturbances):
                        break
                else:
                    obs = self.observe()
                    if self.mode == "COUPLED_B":
                        seq = self.ledger.append(self.now, "PERCEPTION", "WRONG_OUTCOME_OBSERVED", obs)
                        self.coupled_response("HARD_CONTRADICTION", obs, seq, always=True)
                    elif self.mode == "HYBRID_C":
                        seq = self.ledger.append(self.now, "PERCEPTION", "WRONG_OUTCOME_OBSERVED", obs)
                        self.switch_topology("COUPLED", "WRONG_OUTCOME", seq)
                        self.coupled_response("HARD_CONTRADICTION", obs, seq)

            # If a repair held because evidence was absent, restoration will
            # create a replacement when resolution arrives. If no plan exists,
            # HYBRID C may resume from restored evidence.
            if self.mode == "HYBRID_C" and self.plan is not None and self.plan.status in {"CANCELLED", "HOLD"}:
                if self.observe()["observedTarget"] is not None and self.topology != "UNCERTAINTY":
                    self.create_plan(self.observe()["observedTarget"], [len(self.ledger.events)])

        else:
            self.metrics["timeout"] = True

        self.metrics["events"] = len(self.ledger.events)
        self.metrics["starvation"] = (
            self.metrics["actions_executed"] == 0
            and self.guard.actuator_route
            and self.guard.permit.present
            and not self.guard.revoked
        )
        if self.metrics["contradiction_at"] is not None and self.metrics["cancel_at"] is not None:
            self.metrics["contradictionToCancelTicks"] = self.metrics["cancel_at"] - self.metrics["contradiction_at"]
        if self.metrics["contradiction_at"] is not None and self.metrics["correction_at"] is not None:
            self.metrics["contradictionToCorrectionTicks"] = self.metrics["correction_at"] - self.metrics["contradiction_at"]

        correct = bool(self.placements and self.placements[-1] == self.true_target)
        distance = abs(self.position - self.true_target)
        quality = max(
            0,
            100
            - distance * 12
            - self.wrong_placements * 14
            - self.metrics["unnecessary_actions"] * 3
        )
        result = {
            "schema": SCHEMA,
            "challenge": CHALLENGE,
            "mode": self.mode,
            "scenarioId": self.scenario["id"],
            "seed": self.scenario["seed"],
            "inputDigest": sha256(self.scenario),
            "authority": AUTHORITY,
            "promotion": "candidate-only",
            "canon": False,
            "metrics": copy.deepcopy(self.metrics),
            "outcome": {
                "position": self.position,
                "trueTarget": self.true_target,
                "distance": distance,
                "placements": self.placements,
                "wrongPlacements": self.wrong_placements,
                "correctFinalPlacement": correct,
                "qualityScore": quality,
            },
            "evidenceReceipt": self.ledger.receipt(),
        }
        result["semanticDigest"] = sha256(result)
        return result


def run_once(fixture: dict[str, Any], scenario: dict[str, Any], mode: str) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    start = time.perf_counter_ns()
    sim = Simulator(fixture, scenario, mode)
    result = sim.run()
    wall = time.perf_counter_ns() - start
    result["resourceObservation"] = {
        "wallClockNanoseconds": wall,
        "note": "Wall clock is host-dependent and excluded from semanticDigest."
    }
    return result, sim.ledger.events


def compare_modes(runs: dict[str, dict[str, Any]]) -> dict[str, Any]:
    def score(mode: str) -> tuple[int, int, int, int]:
        r = runs[mode]
        m = r["metrics"]
        return (
            r["outcome"]["qualityScore"],
            -m["unnecessary_actions"],
            -m["actions_later_repaired"],
            -m["events"],
        )
    order = sorted(MODES, key=lambda m: score(m), reverse=True)
    best = order[0]
    return {
        "scenarioId": next(iter(runs.values()))["scenarioId"],
        "quality": {m: runs[m]["outcome"]["qualityScore"] for m in MODES},
        "unnecessaryActions": {m: runs[m]["metrics"]["unnecessary_actions"] for m in MODES},
        "cancelTicks": {m: runs[m]["metrics"]["contradictionToCancelTicks"] for m in MODES},
        "events": {m: runs[m]["metrics"]["events"] for m in MODES},
        "falseContradictions": {m: runs[m]["metrics"]["false_contradictions"] for m in MODES},
        "bestByQualityThenCost": best,
        "hybridTopology": {
            "switches": runs["HYBRID_C"]["metrics"]["mode_switches"],
            "coupledActivations": runs["HYBRID_C"]["metrics"]["coupled_activations"],
            "uncertaintyActivations": runs["HYBRID_C"]["metrics"]["uncertainty_activations"],
            "preventedFalsePreemptions": runs["HYBRID_C"]["metrics"]["prevented_false_preemptions"],
        },
    }


def validate_ledger(events: list[dict[str, Any]]) -> list[str]:
    errors = []
    for i, event in enumerate(events, 1):
        if event.get("seq") != i:
            errors.append(f"non-monotonic seq {event.get('seq')} expected {i}")
        if any(p <= 0 or p >= i for p in event.get("causalParents", [])):
            errors.append(f"invalid causal parent at {i}")
    return errors


def benchmark(fixture_path: Path, output: Path, repeats: int = 2) -> dict[str, Any]:
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    runs: list[dict[str, Any]] = []
    comparisons: list[dict[str, Any]] = []
    repeatability = []
    ledgers: dict[tuple[str, str], list[dict[str, Any]]] = {}
    ledger_errors = []

    for scenario in fixture["scenarios"]:
        per_mode: dict[str, dict[str, Any]] = {}
        for mode in MODES:
            result, events = run_once(fixture, scenario, mode)
            runs.append(result)
            per_mode[mode] = result
            ledgers[(scenario["id"], mode)] = events
            ledger_errors.extend(f"{scenario['id']}/{mode}: {x}" for x in validate_ledger(events))
            reruns = []
            for _ in range(max(1, repeats) - 1):
                rr, _ = run_once(fixture, scenario, mode)
                reruns.append(rr["semanticDigest"])
            repeatability.append({
                "scenarioId": scenario["id"],
                "mode": mode,
                "primary": result["semanticDigest"],
                "reruns": reruns,
                "repeatable": all(x == result["semanticDigest"] for x in reruns),
            })
        comparisons.append(compare_modes(per_mode))

    output.mkdir(parents=True, exist_ok=True)
    ledger_dir = output / "causal-ledgers"
    ledger_dir.mkdir(exist_ok=True)
    for (sid, mode), events in ledgers.items():
        (ledger_dir / f"{sid}--{mode.lower()}.jsonl").write_text(
            "".join(json.dumps(x, sort_keys=True, separators=(",", ":")) + "\n" for x in events),
            encoding="utf-8"
        )

    raw = {
        "schema": "axm.adaptive-reasoning-abc-benchmark/v0.26",
        "challenge": CHALLENGE,
        "fixtureDigest": sha256(fixture),
        "authority": AUTHORITY,
        "promotion": "candidate-only",
        "canon": False,
        "runs": runs,
        "comparisons": comparisons,
    }
    (output / "raw-metrics.json").write_text(json.dumps(raw, indent=2, sort_keys=True) + "\n")
    rep = {
        "schema": "axm.repeatability-evidence/v0.26",
        "allRepeatable": all(x["repeatable"] for x in repeatability),
        "ledgerValidationErrors": ledger_errors,
        "runs": repeatability,
    }
    (output / "repeatability.json").write_text(json.dumps(rep, indent=2, sort_keys=True) + "\n")
    return {"fixture": fixture, "raw": raw, "repeatability": rep}


def build_summary(bundle: dict[str, Any], output: Path) -> None:
    raw = bundle["raw"]
    lines = [
        "# v0.26 adaptive reasoning A/B/C benchmark",
        "",
        f"Challenge: `{CHALLENGE}`",
        "",
        "A = fixed sequential. B = always coupled. C = adaptive hybrid.",
        "",
        "The selector can change reasoning topology only. It has no execution authority.",
        "",
        "| Scenario | A quality | B quality | C quality | A unnecessary | B unnecessary | C unnecessary | A cancel | B cancel | C cancel | C switches | Best |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for c in raw["comparisons"]:
        q, u, k = c["quality"], c["unnecessaryActions"], c["cancelTicks"]
        lines.append(
            f"| {c['scenarioId']} | {q['SEQUENTIAL_A']} | {q['COUPLED_B']} | {q['HYBRID_C']} | "
            f"{u['SEQUENTIAL_A']} | {u['COUPLED_B']} | {u['HYBRID_C']} | "
            f"{k['SEQUENTIAL_A']} | {k['COUPLED_B']} | {k['HYBRID_C']} | "
            f"{c['hybridTopology']['switches']} | {c['bestByQualityThenCost']} |"
        )
    hybrids = [r for r in raw["runs"] if r["mode"] == "HYBRID_C"]
    summary = {
        "scenarioCount": len(raw["comparisons"]),
        "hybridBestCount": sum(c["bestByQualityThenCost"] == "HYBRID_C" for c in raw["comparisons"]),
        "hybridQualityAtLeastBothCount": sum(
            c["quality"]["HYBRID_C"] >= max(c["quality"]["SEQUENTIAL_A"], c["quality"]["COUPLED_B"])
            for c in raw["comparisons"]
        ),
        "hybridPreventedFalsePreemptions": sum(r["metrics"]["prevented_false_preemptions"] for r in hybrids),
        "hybridUncertaintyActivations": sum(r["metrics"]["uncertainty_activations"] for r in hybrids),
        "hybridCoupledActivations": sum(r["metrics"]["coupled_activations"] for r in hybrids),
    }
    lines += [
        "",
        "## Aggregate",
        "",
        f"- Hybrid best by quality-then-cost in {summary['hybridBestCount']} / {summary['scenarioCount']} scenarios.",
        f"- Hybrid quality >= both fixed modes in {summary['hybridQualityAtLeastBothCount']} / {summary['scenarioCount']} scenarios.",
        f"- Hybrid uncertainty activations: {summary['hybridUncertaintyActivations']}.",
        f"- Hybrid coupled activations: {summary['hybridCoupledActivations']}.",
        f"- Prevented noise-driven preemptions recorded: {summary['hybridPreventedFalsePreemptions']}.",
        "",
        "## Claim boundary",
        "",
        "This benchmark tests a deterministic simulator and a reasoning-topology policy. It does not establish general reasoning superiority, consciousness, free thought, emergence, real-world safety, or physical latency improvement.",
    ]
    (output / "BENCHMARK-SUMMARY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    ps = {
        "schema": "axm.research-probe-summary/v0.26",
        "challenge": CHALLENGE,
        "status": "DETACHED_DETERMINISTIC_SIMULATION_OBSERVED",
        **summary,
        "repeatabilityPass": bundle["repeatability"]["allRepeatable"],
        "ledgerValidationPass": not bundle["repeatability"]["ledgerValidationErrors"],
        "authority": AUTHORITY,
        "promotion": "candidate-only",
        "canon": False,
        "claims": {
            "hybridTopologyExecutedInSimulator": True,
            "reasoningModeSelectorGrantedExecutionAuthority": False,
            "realRobotObserved": False,
            "liveModelProviderObserved": False,
            "generalReasoningSuperiorityProven": False,
            "consciousnessObserved": False,
        },
    }
    ps["receiptDigest"] = sha256(ps)
    (output / "probe-summary.json").write_text(json.dumps(ps, indent=2, sort_keys=True) + "\n")
    rp = {
        "schema": "axm.return-packet/v0.26",
        "challenge": CHALLENGE,
        "candidateBranch": "axm/mirror-waldo-experiment-v0.26-hybrid-reasoning-ab",
        "mergeRequested": False,
        "prRequested": False,
        "authority": AUTHORITY,
        "promotion": "candidate-only",
        "canon": False,
        "probeSummaryReceipt": ps["receiptDigest"],
        "holds": [
            "Fresh v0.26 simulator is not a physical robot or provider-backed reasoning runtime.",
            "Reasoning-mode policy must be validated on larger non-handpicked scenario/seed sets before stronger claims.",
        ],
    }
    rp["returnDigest"] = sha256(rp)
    (output / "return-packet.json").write_text(json.dumps(rp, indent=2, sort_keys=True) + "\n")


def build_auxiliary_artifacts(bundle: dict[str, Any], root: Path, output: Path) -> None:
    runs = bundle["raw"]["runs"]
    failure_rows = []
    for r in runs:
        m = r["metrics"]
        noteworthy = (
            r["outcome"]["qualityScore"] < 100
            or m["false_contradictions"] > 0
            or m["holds"] > 0
            or m["starvation"]
            or (r["mode"] == "HYBRID_C" and (m["mode_switches"] > 0 or m["uncertainty_activations"] > 0))
        )
        if noteworthy:
            failure_rows.append({
                "scenarioId": r["scenarioId"],
                "mode": r["mode"],
                "qualityScore": r["outcome"]["qualityScore"],
                "unnecessaryActions": m["unnecessary_actions"],
                "falseContradictions": m["false_contradictions"],
                "holds": m["holds"],
                "starvation": m["starvation"],
                "modeSwitches": m["mode_switches"],
                "uncertaintyActivations": m["uncertainty_activations"],
                "coupledActivations": m["coupled_activations"],
            })
    failure = {
        "schema": "axm.adaptive-reasoning-failure-evidence/v0.26",
        "note": "Negative and mixed evidence is retained. In particular, ambiguous-real-target-change is an intentional Hybrid C loss.",
        "rows": failure_rows,
    }
    (output / "failure-evidence.json").write_text(json.dumps(failure, indent=2, sort_keys=True) + "\n")

    manifest = {
        "schema": "axm.artifact-manifest/v0.26",
        "files": {},
        "note": "Manifest excludes itself to avoid self-reference. Git blob identities are added by publication evidence separately.",
    }
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.name == "artifact-manifest.json":
            continue
        rel = path.relative_to(root).as_posix()
        data = path.read_bytes()
        manifest["files"][rel] = {"sha256": sha256(data), "bytes": len(data)}
    manifest["manifestReceipt"] = sha256(manifest)
    (output / "artifact-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--fixture", type=Path, default=Path(__file__).with_name("scenarios.json"))
    p.add_argument("--output", type=Path, default=Path(__file__).with_name("artifacts"))
    p.add_argument("--repeat", type=int, default=2)
    args = p.parse_args(argv)
    if args.repeat < 2:
        p.error("--repeat >= 2")
    bundle = benchmark(args.fixture, args.output, args.repeat)
    build_summary(bundle, args.output)
    build_auxiliary_artifacts(bundle, Path(__file__).parent, args.output)
    ok = bundle["repeatability"]["allRepeatable"] and not bundle["repeatability"]["ledgerValidationErrors"]
    print(json.dumps({"status": "PASS" if ok else "FAIL", "output": str(args.output), "authority": AUTHORITY}, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
